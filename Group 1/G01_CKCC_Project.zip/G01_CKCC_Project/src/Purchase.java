public class Purchase {
    private String orderNo;
    private Product product;
    private double qty,discount;
    public Purchase(){}
    public Purchase(String orderNo, Product product, double qty, double discount) {
        this.orderNo = orderNo;
        this.product = product;
        this.qty = qty;
        this.discount = discount;
    }
    public double getQty(){
        return qty;
    }
    public String getOrderNo(){
        return orderNo;
    }
    public double getPrice(){
        return product.getPrice()*qty*(1-discount/100);
    }
    public Product pro(){
        return product;
    }
    public String toString(){
        return orderNo+"\t\t"+product.getName()+"\t\t"+product.getPrice()+"$\t\t"+qty+"\t\t"+discount+"%\t\t"+getPrice()+"$";
    }
}
