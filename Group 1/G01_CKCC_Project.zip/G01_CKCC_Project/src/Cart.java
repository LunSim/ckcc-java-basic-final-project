import java.util.ArrayList;

public class Cart {
    public ArrayList<Purchase> purchasedItems = new ArrayList<>();
    private double discount;
    public Cart(){}
    public Cart(double discount){
        this.discount=discount;
    }
    public void addItem(Purchase item){
        purchasedItems.add(item);
    }
    public void removeItem(Purchase item){
        purchasedItems.remove(item);
    }
    public ArrayList<Purchase> getPurchasedItem(){
        for(int i=0;i<purchasedItems.size();i++){
            getPurchasedItem().add(purchasedItems.get(i));
        }
        return getPurchasedItem();
    }
    public void setDiscount(double discount){
           this.discount = calculateSubTotal()*discount;
    }
    public double getDiscount(){
        return discount;
    }
    public double calculateSubTotal(){
        double subTotal=0;
        for(int i=0;i<purchasedItems.size();i++){
            subTotal+=purchasedItems.get(i).getPrice();
        }
        return subTotal;
    }
    public double calculateTotal(){
        return calculateSubTotal()-discount;
    }
    public String toString(){
        return  "\n\nSubtotal    :$"+calculateSubTotal()+
                "\nDiscount    :$"+getDiscount()+
                "\n\nGrandTotal  :$"+calculateTotal()+
                "\n\nThank You!";
    }

}
