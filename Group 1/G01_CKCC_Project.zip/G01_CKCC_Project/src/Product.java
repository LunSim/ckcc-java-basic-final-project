import java.util.ArrayList;

public class Product {
    private String id,name,description;
    private double price,qtyInStock;
    public Product(){}
    public Product(String id, String name, String description, double price, double qtyInStock) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.qtyInStock = qtyInStock;
    }
    ArrayList<Product> allProduct = new ArrayList<>();
    public String getId(){
        return id;
    }
    public String getDescription(){
        return description;
    }
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getQtyInStock() {
        return qtyInStock;
    }
    public  boolean isValidStock(double qty){
        if(qtyInStock>=qty){
            return true;
        }
        else
            return  false;
    }
    public String toString(){
        return id+"\t\t"+name+"\t\t"+price+"\t\t"+qtyInStock+"\t\t"+description+"\n";
    }
    public boolean checkDuplicate(String Id) {
        for (int i = 0; i < allProduct.size(); i++) {      //find duplicate id
            if (allProduct.get(i).getId().equals(Id)) {
                System.out.println("ID is duplicated!!!");

                return true;

            }


        }
        return false;

    }

}
