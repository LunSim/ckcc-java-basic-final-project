import com.sun.org.apache.xpath.internal.SourceTree;

import java.awt.*;
import java.util.Scanner;

public class Transaction {
    Scanner sc = new Scanner(System.in);
    Product product = new Product();
    Purchase purchase = new Purchase();
    Cart cart = new Cart();
    Customer customer = new Customer();
    int orderID=1;
    public static void main(String[] args) {
        Transaction t = new Transaction();
        t.welcome();
    }
    public void welcome(){
        System.out.println("-------Welcome-------");
        System.out.println("1. New Product");
        System.out.println("2. List of Products");
        System.out.println("3. Go to Shopping");
        System.out.println("4. My Shopping Cart");
        System.out.println("5. Check Out");
        System.out.print("Select Transaction: ");
        switch (sc.nextLine()){
            case "1": newProduct(); break;
            case "2": listOfProducts(); break;
            case "3": goToShopping(); break;
            case "4": myShoppingCart(); break;
            case "5": checkOut(); break;
            default:
                System.out.println("Invalid transaction!!!");
                welcome();
                break;
        }
    }
    public void newProduct(){
        System.out.println("-------Add New Product-------");
        System.out.print("Enter Product ID: ");
        String id = sc.nextLine();
//System.outfor(int i =0;i<product.allProduct.size();i++){      //find duplicate id
//            if(product.allProduct.get(i).getId().equals(id)){
//                System.out.println("ID is duplicated!!!");
//                newProduct();
//                return;
//            }
//        }.print("Enter Product Name: ");
        if(product.checkDuplicate(id)) {
            newProduct();


            return;
        }
        System.out.print("Enter product Name:");
        String name = sc.nextLine();
        System.out.print("Enter Description: ");
        String description = sc.nextLine();
        while(true){
        try{        //validate data
            System.out.print("Enter Product Price: ");
            double price = Double.parseDouble(sc.nextLine());
            System.out.print("Enter Product QTY: ");
            double qty = Double.parseDouble(sc.nextLine());
            product.allProduct.add(new Product(id,name,description,price,qty));     //add to collection
            break;
        }
        catch (Exception e){
            System.out.println("Price and QTY must be number.");

        }}
        System.out.println("Add more Product?(Y/anyKey): ");
        switch (sc.nextLine().toLowerCase()){
            case "y": newProduct();break;
            default: welcome();
        }

    }
    public void listOfProducts(){
        System.out.println("-------List of Products-------");
        System.out.println("ID\t\tName\t\tPirce\t\tQty\t\tDescription");
        for(int i=0;i<product.allProduct.size();i++){       //loop for display all products
//            System.out.println(product.allProduct.get(i).getId()+"\t\t"+product.allProduct.get(i).getName()+"\t\t"+
//                    product.allProduct.get(i).getPrice()+"\t\t"+product.allProduct.get(i).getQtyInStock()+"\t\t"+
//                    product.allProduct.get(i).getDescription());
            System.out.println(product.allProduct.get(i).toString());
        }
        welcome();
    }
    public void goToShopping(){
        int check=0;
        System.out.println("-------Shopping-------");
        System.out.print("Enter Product ID: ");
        String id = sc.nextLine();
        for(int i=0;i<product.allProduct.size();i++){       //search for product via id
            if(product.allProduct.get(i).getId().equals(id)){
                System.out.println("Name\tPrice");
                System.out.println(product.allProduct.get(i).getName()+"\t"+product.allProduct.get(i).getPrice());
                while (true){
                    try{
                        System.out.print("Enter qty: ");
                        double qty = Double.parseDouble(sc.nextLine());

                        if(product.allProduct.get(i).isValidStock(qty)==false){     //check stock qty
                            System.out.println("Insufficient Qty in Stock!");
                            break;
                        }
                        System.out.print("Enter Discount: ");
                        double discount = Double.parseDouble(sc.nextLine());
                        cart.addItem(new Purchase(orderID+"",product.allProduct.get(i),qty,discount));
                        product.allProduct.set(i,new Product(product.allProduct.get(i).getId(),product.allProduct.get(i).getName(),     //deduct stock qty
                                product.allProduct.get(i).getDescription(),product.allProduct.get(i).getPrice(),
                                product.allProduct.get(i).getQtyInStock()-qty));
                        System.out.println("Item added.");
                        orderID++;
                        System.out.print("Want to shop more? (Y/anykey): ");
                        switch (sc.nextLine().toLowerCase()){
                            case "y":goToShopping();return;
                            default:break;
                        }
                        break;
                    }
                    catch(Exception e){
                        System.out.println("Please enter number only!");
                    }
                }
                check =1;
                break;
            }
            check=0;
        }
        if(check==0){
            System.out.println("Invalid Product ID!!!");


        }
        welcome();

    }
    public void myShoppingCart(){
        System.out.println("-------My Shopping Cart-------");
        System.out.println("No\t\tName\t\tPrice\t\tQty\t\tDiscount\t\tTotal");
        for(int i=0;i<cart.purchasedItems.size();i++){          //loop for display
            System.out.println(cart.purchasedItems.get(i));
        }
        System.out.print("Do you want to remove any items? (Y or anykey): ");
        switch (sc.nextLine().toLowerCase()){
            case "y":
                while (true){
                try{
                    System.out.print("Enter order Number to remove: ");
                    String remove = sc.nextLine();
                    for(int i=0;i<cart.purchasedItems.size();i++){      //find product id to remove
                        if(cart.purchasedItems.get(i).getOrderNo().equals(remove)){

                            String id =cart.purchasedItems.get(i).pro().getId();
                            double qty = cart.purchasedItems.get(i).getQty();
                            cart.removeItem(cart.purchasedItems.get(i));
                            for(int j=0;j<product.allProduct.size();j++){

                                if(product.allProduct.get(j).getId().equals(id)){       //update stock qty after remove item
                                    product.allProduct.set(j,new Product(product.allProduct.get(j).getId(),
                                            product.allProduct.get(j).getName(),product.allProduct.get(j).getDescription(),
                                            product.allProduct.get(j).getPrice(),product.allProduct.get(j).getQtyInStock()+qty));
                                    System.out.println("Item is removed!");
                                    myShoppingCart();break;
                                }
                            }
                            break;
                        }
                    }
                    System.out.println("Invalid Order Number");
                    myShoppingCart();
                    break;
                }
                catch(Exception e){
                    System.out.println("Please input number only!");
                }
                }myShoppingCart();break;

                default:
                    System.out.println("Invalid input!");
                    welcome();
                    break;
        }
        //welcome();
    }
    public void checkOut(){

        System.out.print("Enter your indentification number: ");
        String idnumber = sc.nextLine();
        System.out.print("Enter your name               : ");
        String name = sc.nextLine();
        System.out.print("Enter your email              : ");
        String email = sc.nextLine();
        System.out.print("Enter your shipping address   : ");
        String shippingAddress = sc.nextLine();
        System.out.print("Enter your billing address    : ");
        String billingAddress = sc.nextLine();
        if(!idnumber.isEmpty()&&!name.isEmpty()&&!email.isEmpty()&&!shippingAddress.isEmpty()&&!billingAddress.isEmpty()){  //validate null field
            while (true){
            try{
            System.out.print("Enter Memership percentage discount: ");
            sc= new Scanner(System.in);
            double dis = sc.nextDouble();
            cart.setDiscount(dis);
            break;}
            catch (Exception e){
                System.out.println("Please ENTER number only!");
            }}
              Customer c = new Customer(idnumber,name,email,shippingAddress,billingAddress);
                System.out.println(c.toString());
                System.out.println(cart.toString());
                return;

        }
        else{
            System.out.println("All fields must not be Empty");
            checkOut();
        }

    }
}
