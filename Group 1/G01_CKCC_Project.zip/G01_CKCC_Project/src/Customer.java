import java.util.Scanner;

public class Customer {
    private String id,name,email,shippingAddress,billingAddress;
    public Cart shoppingCart=new Cart();
    Scanner sc = new Scanner(System.in);
    Customer(){}
    public Customer(String id, String name, String email, String shippingAddress, String billingAddress) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.shippingAddress = shippingAddress;
        this.billingAddress = billingAddress;
    }
    public void placeOrder(Cart shoppingCart){

    }
    public void cancelOrder(){

        System.out.println("Ordering has been cancelled!");
        System.out.println("Thank you!");

    }
    public String checkOut(){
        return shoppingCart.toString();

    }
    public String toString(){
        return "Customer ID:"+this.id+
                "\t\nName:"+this.name+
                "\nEmail:"+this.email+
                "\nShipping Address:"+this.shippingAddress+
                "\nBilling Address:"+this.shippingAddress;

    }
}
