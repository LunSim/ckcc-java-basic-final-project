package shoppingCart;

public class Customer {
	
	private String id;
	private String name;
	private Address shippingAddress;
	private Address billingAddress;
	private Cart shoppingCart;
	
	public Customer(String id,String name,Address shippingAddress,Address billingAddress) {
		
		this.setId(id);
		this.setName(name);
		this.shippingAddress = shippingAddress;
		this.billingAddress = billingAddress;
		 
	}
	@Override
	public String toString() {
		 
		return shippingAddress.toString() + "\n" + billingAddress.toString();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

}
