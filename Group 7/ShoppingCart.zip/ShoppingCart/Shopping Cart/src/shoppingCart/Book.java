package shoppingCart;

public class Book extends Item{
	
	private String author;
	private int edition;
	private int volume;
	
	public Book(String title,String publisher,String yearPublished,String ISBN,double priceInOne,String author,int edition,int volume) {
		 
		super(title, publisher, yearPublished, ISBN, priceInOne);
		this.author = author;
		this.edition = edition;
		this.volume = volume;
		
	}
	
	@Override
	public String toString() {
	  
		return " (Catagory BOOK:) "+ super.toString() + author + "(Author)" + "\t" + 
				edition + "(Edition)" + "\t" + volume + "(Volume)" + "\t";
	}
	

}
