package shoppingCart;

public class Address {
	
	private String street;
	private String city;
	private String state;
	private String country;
	private String postalCode;
	private double shoppingFee;
	
	public Address() {
		 
	}
	public Address(String street,String city,String state,String country,String postalCode,double shoppingFee) {
		
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.postalCode = postalCode;
		this.shoppingFee = shoppingFee;
		
	}
	
	public double getShoppingFee() {
		return shoppingFee;
	}
	
	@Override
	public String toString() {
		 
		return "Street:\t"+street + "\n" + "City:\t"+city +"\n"
				+"State:\t"+ state + "\n" +"Country:\t"+ country +"\n" 
				+"PostalCode:\t"+ postalCode + "\n" +"ShippingFee:\t" + shoppingFee + "\n" ;
	}

}
