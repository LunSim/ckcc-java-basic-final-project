package shoppingCart;

public class ItemOrder {
	
	private Item item;
	private int qty;
	
	public ItemOrder(Item item,int qty) {
		
		this.item = item;
		this.qty = qty;
		 
	}
	
	public double getPrice() {
		
		return qty * item.getPriceInOne();
		
	}
	
	@Override
	public String toString() {
		 
		return item.toString() + qty + "(Qty)" + "\t" + getPrice() + "$" + "\t";
	}
	
	public Item getItem() {
		return item;
	}

}
