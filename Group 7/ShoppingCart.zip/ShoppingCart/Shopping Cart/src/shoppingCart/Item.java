package shoppingCart;

public class Item {
	
	private String title;
	private String publisher;
	private String yearPublished;
	private String ISBN;
	private double priceInOne;
	
	public Item(String title,String publisher,String yearPublished,String ISBN,double priceInOne) {
		
		this.title = title;
		this.publisher = publisher;
		this.yearPublished = yearPublished;
		this.ISBN = ISBN;
		this.priceInOne = priceInOne;
		 
	}
	
	@Override
	public String toString() {
		 
		return  title +"(Title)" + "\t" + publisher +"(Publisher)" + "\t" + yearPublished +"(Year-Published)"+
				"\t" + ISBN + "(ISBN)" + "\t" + priceInOne + "$" + "\t";
	}
	
	public double getPriceInOne() {
		
		return priceInOne;
		
	}
	
	public String getISBN () {
		
		return ISBN;
		
	}
	public String getTitle() {
		return title;
	}

}
