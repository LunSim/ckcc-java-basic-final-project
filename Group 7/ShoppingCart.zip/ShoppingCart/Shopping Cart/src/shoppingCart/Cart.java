package shoppingCart;

import java.util.ArrayList;

public class Cart {
	
	private ArrayList<ItemOrder> purchasedItems = new ArrayList<>();
	private double discount;
	private double shippingFee;
	
	public Cart() {
		
		 
	}
	
	public void addItem(ItemOrder itemOrder) {
		
		 purchasedItems.add(itemOrder);
		
	}
	
	public void removeItem (ItemOrder itemOrder) {
		 for(int i = 0 ;i<purchasedItems.size() ; i++) {
			 if(purchasedItems.get(i).getItem().getISBN().compareTo(itemOrder.getItem().getISBN())==0) {
				 purchasedItems.remove(i);
			 }
		 }
	}
	
	public  ArrayList<ItemOrder> getPurchasedItems() {
		return purchasedItems;
	}
	public ArrayList<ItemOrder> setPurchasedItems(ItemOrder itemOrder){
		 purchasedItems.add(itemOrder);
		 return purchasedItems;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(double shippingFee) {
		this.shippingFee = shippingFee;
	}
	
	public double subTotal () {
		double subTotal = 0;
		for(int i = 0 ; i < purchasedItems.size() ; i++) {
			subTotal += purchasedItems.get(i).getPrice();
		}
		
		return subTotal + getShippingFee();
	}
	
	public double total () {
		double total = 0;
		
		for(int i = 0 ;i < purchasedItems.size() ; i++) {
			total += purchasedItems.get(i).getPrice();
		}
		total += getShippingFee();
		total = total - (total * getDiscount());
		return total;
		
	}
	
	public String getYourCart() {
		String str  = "";
		for(int i = 0 ; i < purchasedItems.size() ; i++) {
			str += purchasedItems.get(i).toString() + "\n";
				    
		}
		return str;
	}
	
	@Override
	public String toString() {
		String str  = "";
	    for(int i = 0 ; i < purchasedItems.size() ; i++) {
			str += purchasedItems.get(i).toString() + "\n";
				    
		}
		
		str += "\n" + " discount = " + discount + "\n Shipping Fee = " + getShippingFee() + "\n subTotal = " + subTotal() + "\n total =   " + total();
		return  str;
	}

}
