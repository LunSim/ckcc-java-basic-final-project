package shoppingCart;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	 

	public static void main(String[] args) {
		
		ArrayList<Item> newProduct = new ArrayList<>();
		ArrayList<ItemOrder> itemOrder = new ArrayList<>();
		Cart cart = new Cart();
		
		int choice;
		int number;
		 
		String again;
		int a = 1;
		Scanner cin = new Scanner(System.in);
		do{
		System.out.println("		_________________________________________________________________________________");	
		System.out.print("					    *******    Menu     ********\n");
		System.out.print("					---      Selections Below        ---\n\n");
		System.out.print("						1) Add New Product \n");
		System.out.print("						2) List of All Product \n");
		System.out.print("						3) List By Catagories\n");
	    System.out.print("						4) Search item \n");
		System.out.print("						5) Go to Shopping\n");
		System.out.print("						6) My Cart\n");
		System.out.print("						7) Remove some Order Item\n");
		System.out.print("						8) Check out/My invoce\n");
		System.out.println("		_________________________________________________________________________________");
		choice = cin.nextInt();
		 

	inner:	switch(choice){
		
		
		 case 1 :
			 	
		        String category;
		        System.out.print("What category of Product:");
		        cin.nextLine();
		        category = cin.nextLine();
		        if(category.compareToIgnoreCase("Book") == 0) {
		        	String title,publisher,yearPublished,ISBN,author;
		        	int edition;
		        	int volume;
		        	double priceInOne;
		        	System.out.print("input Title:");			title = cin.nextLine();
		        	System.out.print("input publisher:");		publisher = cin.nextLine();
		        	System.out.print("input yearPublished:");	yearPublished = cin.nextLine();
		        	System.out.print("input ISBN:");			ISBN = cin.nextLine();
		        	System.out.print("input price unit:");		priceInOne = cin.nextDouble();
		        	System.out.print("input author:");	  		cin.nextLine();author = cin.nextLine();
		        	System.out.print("input edition:");			edition = cin.nextInt();
		        	System.out.print("input volume:");			volume = cin.nextInt();
		        	Item obj = new Book(title, publisher, yearPublished, ISBN, priceInOne, author, edition, volume);
		        	
		        	newProduct.add(obj);		        	
		        }
		        else if(category.compareToIgnoreCase("MusicCD") == 0) {
		        	String title,publisher,yearPublished,ISBN,artist;
		        	double priceInOne;
		        	int volume;
		        	
		        	System.out.print("input Title:");			title = cin.nextLine();
		        	System.out.print("input publisher:");		publisher = cin.nextLine();
		        	System.out.print("input yearPublished:");	yearPublished = cin.nextLine();
		        	System.out.print("input ISBN:");			ISBN = cin.nextLine();
		        	System.out.print("input price unit:");		priceInOne = cin.nextDouble();
		        	System.out.print("input artist:");	  		cin.nextLine();artist = cin.nextLine();
		        	System.out.print("input volume:");			volume = cin.nextInt();
		        	
		        	Item obj = new MusicCD(title, publisher, yearPublished, ISBN, priceInOne, artist, volume);
		        	
		        	newProduct.add(obj);
		        	
		        }
		        
		        else if(category.compareToIgnoreCase("Magazine") == 0) {
		        	String title,publisher,yearPublished,ISBN,issueDate,editor;
		        	double priceInOne;
		        	int issueNo;
		        	System.out.print("input Title:");			title = cin.nextLine();
		        	System.out.print("input publisher:");		publisher = cin.nextLine();
		        	System.out.print("input yearPublished:");	yearPublished = cin.nextLine();
		        	System.out.print("input ISBN:");			ISBN = cin.nextLine();
		        	System.out.print("input price unit:");		priceInOne = cin.nextDouble();
		        	System.out.print("input issueNo:");			issueNo = cin.nextInt();
		        	System.out.print("input issueDate:");		cin.nextLine(); issueDate = cin.nextLine();
		        	System.out.print("input editor:");			editor = cin.nextLine();
		        	
		        	Item obj = new Magazine(title, publisher, yearPublished, ISBN, priceInOne, issueNo, issueDate, editor);
		        	
		        	newProduct.add(obj);
		        	
		        }
		        
		        else {
		        	System.out.println("No this Catagory in Our Shopp");
		        }
		        
		        break;
		        
		        
		    case 2 :
		    	
		    	for(int i = 0 ; i < newProduct.size() ; i++) {
		    		System.out.println(newProduct.get(i).toString());
		    	}
		    	
		        break;

		    case 3 :
		    	String catagory ;
		    	System.out.print("which catagory you want to List:");
		    	cin.nextLine();
		    	catagory  = cin.nextLine();
		    	for(int i = 0 ;i < newProduct.size() ; i++) {
		 
		    		if(newProduct.get(i).getClass().getName().compareToIgnoreCase("shoppingCart."+catagory) == 0) {
		    			 System.out.println(newProduct.get(i).toString());
		    		}
		    	}
		        break;

		    case 4 :
		    	String searchCatagory;
		    	
		    	System.out.print("input Catagory First:");
		    	cin.nextLine();
		    	searchCatagory = cin.nextLine();
		    	if(searchCatagory.compareToIgnoreCase("Book") == 0) {
		    		String titleOfBook;
		    		boolean search = false;
		    		
		    		System.out.print("input title of book:");
		    		
		    		titleOfBook = cin.nextLine();
		    		for(int i = 0 ;i < newProduct.size() ; i++) {
		    			
			    			 if(newProduct.get(i).getTitle().compareToIgnoreCase(titleOfBook) == 0) {
			    				 System.out.println(newProduct.get(i).toString());
			    				 search = true;
			    				  
			    			 }  	
			    	}
		    		
		    		if(search == false) {
		    			System.out.println(titleOfBook + " Not fund! in our Product");
		    		}
		    			
		    	}
		    	
		    	if(searchCatagory.compareToIgnoreCase("MusicCD") == 0) {
		    		String titleOfMusicCD;
		    		boolean search = false;
		    		
		    		System.out.print("input title of MusicCD:");
		    		
		    		titleOfMusicCD = cin.nextLine();
		    		for(int i = 0 ;i < newProduct.size() ; i++) {
		    			
			    			 if(newProduct.get(i).getTitle().compareToIgnoreCase(titleOfMusicCD) == 0) {
			    				 System.out.println(newProduct.get(i).toString());
			    				 search = true;
			    				  
			    			 }  	
			    	}
		    		
		    		if(search == false) {
		    			System.out.println(titleOfMusicCD + " Not fund! in our Product");
		    		}
		    			
		    	}
		    	
		    	if(searchCatagory.compareToIgnoreCase("Magazine") == 0) {
		    		String titleOfMagazine;
		    		boolean search = false;
		    		
		    		System.out.print("input title of Magazine:");
		    		
		    		titleOfMagazine = cin.nextLine();
		    		for(int i = 0 ;i < newProduct.size() ; i++) {
		    			
			    			 if(newProduct.get(i).getTitle().compareToIgnoreCase(titleOfMagazine) == 0) {
			    				 System.out.println(newProduct.get(i).toString());
			    				 search = true;
			    				  
			    			 }  	
			    	}
		    		
		    		if(search == false) {
		    			System.out.println(titleOfMagazine + " Not fund! in our Product");
		    		}
		    			
		    	}
		        break;

		    case 5 :
		    	 String catagoryOfProduct;
		    	 
		    	 int qty;
		    	 cin.nextLine();
		    	 System.out.print("which Catagory you want to Order:"); catagoryOfProduct = cin.nextLine();
		    	 if(catagoryOfProduct.compareToIgnoreCase("book") == 0) {
		    		 String bookTitle;
		    		 System.out.print("input title of Book:"); bookTitle = cin.nextLine();
		    		 System.out.print("input qty of Book:");   qty = cin.nextInt();
		    		 for(int i = 0 ; i<newProduct.size() ; i++) {
		    			 if(newProduct.get(i).getTitle().compareToIgnoreCase(bookTitle) == 0) {
		    				 Item item = newProduct.get(i);
		    				 ItemOrder obj = new ItemOrder(item, qty);
		    				 itemOrder.add(obj);
		    				 cart.setPurchasedItems(obj);
		    			 }
		    		 }
		    	 }
		    	 
		    	 if(catagoryOfProduct.compareToIgnoreCase("musiccd") == 0) {
		    		 String musicCDTitle;
		    		 System.out.print("input title of musicCD:"); musicCDTitle = cin.nextLine();
		    		 System.out.print("input qty of MusicCD:");   qty = cin.nextInt();
		    		 for(int i = 0 ; i<newProduct.size() ; i++) {
		    			 if(newProduct.get(i).getTitle().compareToIgnoreCase(musicCDTitle) == 0) {
		    				 Item item = newProduct.get(i);
		    				 ItemOrder obj = new ItemOrder(item, qty);
		    				 itemOrder.add(obj);
		    				 cart.setPurchasedItems(obj);
		    			 }
		    		 }
		    	 }
		    	 
		    	 if(catagoryOfProduct.compareToIgnoreCase("magazine") == 0) {
		    		 String magazineTitle;
		    		 System.out.print("input title of Magazine:"); magazineTitle = cin.nextLine();
		    		 System.out.print("input qty of Magazine:");   qty = cin.nextInt();
		    		 for(int i = 0 ; i<newProduct.size() ; i++) {
		    			 if(newProduct.get(i).getTitle().compareToIgnoreCase(magazineTitle) == 0) {
		    				 Item item = newProduct.get(i);
		    				 ItemOrder obj = new ItemOrder(item, qty);
		    				 itemOrder.add(obj);
		    				 cart.setPurchasedItems(obj);
		    			 }
		    		 }
		    	 }
		    	 
		    	 break;
		    	 
		    case 6:
		    	 
		    	System.out.println("                     				----My Shopping Cart---- ");
		    	
		    	for(int i = 0 ; i <cart.getPurchasedItems().size(); i++) {
		    		
		    		System.out.println(cart.getPurchasedItems().get(i).toString());
		    		
		    		
		    	}
		    	
		    	break;
		    	
		    	
		    case 7:
		    	String cataProduct;
		    	System.out.print(" input Catagory of product First: ");
		    	cin.nextLine();
		    	cataProduct = cin.nextLine();
		    	if(cataProduct.compareToIgnoreCase("Book") == 0) {
		    		String titleOfBook;
		    		System.out.print("input Title of Book to Delete:");
		    		titleOfBook = cin.nextLine();
		    		for(int i = 0 ; i < cart.getPurchasedItems().size(); i++) {
		    			
		    			if(cart.getPurchasedItems().get(i).getItem().getTitle().compareToIgnoreCase(titleOfBook) == 0) {
		    				cart.getPurchasedItems().remove(i);
		    			}
		    			
		    		}
		    	}
		    	
		    	else if(cataProduct.compareToIgnoreCase("musiccd") == 0) {
		    		String titleOfMusicCD;
		    		System.out.print("input Title of MusicCD to Delete:");
		    		titleOfMusicCD = cin.nextLine();
		    		for(int i = 0 ; i < cart.getPurchasedItems().size(); i++) {
		    		  
		    			if(cart.getPurchasedItems().get(i).getItem().getTitle().compareToIgnoreCase(titleOfMusicCD) == 0) {
		    				cart.getPurchasedItems().remove(i);
		    			}
		    			
		    		}
		    	}
		    	
		    	else if(cataProduct.compareToIgnoreCase("magazine") == 0) {
		    		String titleOfMagazine;
		    		System.out.print("input Title of Magazine to Delete:");
		    		titleOfMagazine = cin.nextLine();
		    		for(int i = 0 ; i < cart.getPurchasedItems().size(); i++) {
		    			if(cart.getPurchasedItems().get(i).getItem().getTitle().compareToIgnoreCase(titleOfMagazine) == 0) {
		    				cart.getPurchasedItems().remove(i);
		    			}
		    			
		    		}
		    	}
		    	
				break; 	
				
		    case 8:
		    	System.out.println("Give us your Information First:");
		    	String street,city,state,country,postalCode,id,name;
		    	double shipp_Fee,disc;
		    	System.out.print("input street:");   		cin.nextLine();  street = cin.nextLine();
		    	System.out.print("input city:");			city = cin.nextLine();
		    	System.out.print("input state:");			state = cin.nextLine();
		    	System.out.print("input country:");			country = cin.nextLine();
		    	System.out.print("input postalCode:");		postalCode = cin.nextLine();
		    	System.out.print("input id:");				id = cin.nextLine();
		    	System.out.print("input name:");			name = cin.nextLine();
		    	System.out.print("input shippingFee:");		shipp_Fee = cin.nextDouble();
		    	System.out.print("input Your Discount :");	disc = cin.nextDouble();
		    	
		    	cart.setDiscount(disc);
		    	System.out.print("Do you want to Billing to This Address or Another Place: (Y/N)");
		    	String cho;
		    	cin.nextLine();
		    	cho = cin.nextLine();
		    	if(cho.compareToIgnoreCase("y") == 0) {
		    		String bstreet,bcity,bstate,bcountry,bpostalCode;
		    		double bshipp_Fee;
		    		System.out.print("input street billing to :");   		bstreet = cin.nextLine();
			    	System.out.print("input city billing to :");			bcity = cin.nextLine();
			    	System.out.print("input state billing to :");			bstate = cin.nextLine();
			    	System.out.print("input country billing to :");			bcountry = cin.nextLine();
			    	System.out.print("input postalCode billing to :");		bpostalCode = cin.nextLine();
			    	System.out.print("input shippingFee billing to :");		bshipp_Fee = cin.nextDouble();
			    	cart.setShippingFee(bshipp_Fee);
			    	
			    	Address billingTo = new Address(bstreet, bcity, bstate, bcountry, bpostalCode, bshipp_Fee);
			    	Address addr = new Address(street, city, state, country, postalCode, shipp_Fee);
			    	Customer cus = new Customer(id, name, addr, billingTo);
			    	System.out.println("				____________________Your Invoce_________________");
		    		 
		    		System.out.println("                            Your Address");
		    		System.out.println("ID:" + cus.getId() + "\nName:" + cus.getName() +"\n" + addr.toString() );
		    		System.out.println("                            Your Billing To");
		    		System.out.print(billingTo.toString());
		    	}
		    	else if(cho.compareToIgnoreCase("n") == 0) {
		    		Address billingTo = new Address(street, city, state, country, postalCode, shipp_Fee);
		    		cart.setShippingFee(shipp_Fee);
		    		Address addr = new Address(street, city, state, country, postalCode, shipp_Fee);
		    		Customer cus = new Customer(id, name, addr, billingTo);
		    		System.out.println("				____________________Your Invoce_________________");
		    		 
		    		System.out.println("                            Customer Address");
		    		System.out.println("ID:" + cus.getId() + "\nName:" + cus.getName() +"\n" + addr.toString() );
		    		System.out.println("                            Billing To");
		    		System.out.print(billingTo.toString());
		    	}
		    	
		    	
		    	
		    	 
		    		System.out.println(cart.toString());
		    	 
		    	 
		    	break;
				}
	
		
	 
		   }while(choice != 9);
	}
}
