package shoppingCart;

public class Magazine extends Item {
	
	private int issueNo;
	private String issueDate;
	private String editor;
	
	public Magazine(String title,String publisher,String yearPublished,String ISBN,double priceInOne,int issueNo,String issueDate,String editor) {
		 
		super(title, publisher, yearPublished, ISBN, priceInOne);
		this.issueNo = issueNo;
		this.issueDate = issueDate;
		this.editor = editor;
		
	}

	@Override
	public String toString() {
		 
		return " (Catagory Magazine:) " + super.toString() + issueNo + "(IssueNO)" + "\t" + issueDate + "(IssueDate)" + "\t" + editor + "(Editor)" + "\t";
	}
	
}
