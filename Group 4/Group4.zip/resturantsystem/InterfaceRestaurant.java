import java.util.List;

public interface InterfaceRestaurant {
	public void create(Object T);
	public List<Object> read();
	public void update(Object T);
	public void delete(Object T);
}
