
public class MainRestaurant {
	public static void main(String[] args) {
		MenuRestaurant menuRestaurant = new MenuRestaurant();
		menuRestaurant.mainCall();
	}
}
