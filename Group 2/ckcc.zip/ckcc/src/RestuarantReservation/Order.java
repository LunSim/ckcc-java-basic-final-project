package RestuarantReservation;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Order implements CRUD<Food>{

	private int ID;
	private Table table;
	private List<Food> listFood = new ArrayList<Food>();
	
	public Order(int ID, Table table, List<Food> listFood) {
		super();
		this.ID = ID;
		this.table = table;
		this.listFood = listFood;
	}
	public Order() {
		// TODO Auto-generated constructor stub
	}
	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public Table getTable() {
		return table;
	}

	public void setTable(Table table) {
		this.table = table;
	}

	public List<Food> getlistFood() {
		return listFood;
	}

	public void setlistFood(List<Food> listFood) {
		this.listFood = listFood;
	}
	
//	================= Create New Food=======================
	
	public static void createNewFood(){
	
				
	}
	
	public void create(Food f) {
		listFood.add(f);
	}
	public void createOrder() {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
			do {
				System.out.print("Order Id: ");
				ID = input.nextInt();
				System.out.print("Enter table number you want to order:  ");
				String codeTable = input.next();
				
				System.out.print("How many foods you want to order? :");
				int numberOfFood;
			    numberOfFood = input.nextInt();
			    table = new Table();
			    table.setID(codeTable);
				Food[] f = new Food[numberOfFood];
				for(int i =0; i<numberOfFood;i++) {
					System.out.print("\tEnter Food code you want to eat:  ");
					String foodCode = input.next();
					f[i] = new Food();
					f[i].setID(foodCode);
					listFood.add(f[i]);
				}
				System.out.println("Do you want to take more reservation?[Y/N]");
			    input.nextLine();
			  //  f = new Food(ID, name, price)
			 } while (input.nextLine().equalsIgnoreCase("y"));
	}

	public List<Food> read() {
		
		return listFood;
	}

	public void update(Food f) {
		
		
	}

	public void delete(Food f) {
		// TODO Auto-generated method stub
		
	}

	public String toString() {
		
		return  "Order #"+ID+"\tTable #"+table.getID()+"\t\n";
	}
	
}
