package airlineproject;

public class DepartureArrivalInfo {
	private char dayOfWeek;
	private int time;
	private char type;
	private String airportCode;
	private String airportGate;
	
	public DepartureArrivalInfo(char dayOfWeek, int time, char type, 
								String airportCode, String airportGate) {
		this.dayOfWeek = dayOfWeek;
		this.time = time;
		this.type = type;
		this.airportCode = airportCode;
		this.airportGate = airportGate;
	}	
	public int getTime() {
		return time;
	}
	public String getAirportCode() {
		return airportCode;
	}
	public String getAirportGate() {
		return airportGate;
	}
	public char getDayOfWeek() {
		return dayOfWeek;
	}
	public String toString() {
		return "Day Of Week = " + dayOfWeek + "\nTime = " + time + "\nType = " + type
				+ "\nAirport Code = " + airportCode + "\nAirport Gate = " + airportGate + "\n";
	}
}
