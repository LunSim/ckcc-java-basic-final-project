package airlineproject;
/*
 * CKCC JAVA TRAINING COURSE
 * Assignment
 * Date : 15-May-2018
 * Topic: AirLine
 */
public class Programme {
	public static void main(String[] args) {
		MainMenu mainmenu = new MainMenu();
		
	}

}
