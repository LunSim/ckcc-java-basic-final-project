package airlineproject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.sun.javafx.collections.MappingChange.Map;

public class FlightSchedule {
	private ArrayList<Airline> airlines;
	private HashMap<String, Flight> flightMap;
	
	public FlightSchedule() {
		airlines = new ArrayList<Airline>();
		flightMap = new HashMap<String, Flight>();
	}
	public void deleteAllRecords() {
		this.airlines.clear();
		this.flightMap.clear();
	}
	//Airline
	public void addAirline(Airline airline) {
		this.airlines.add(airline);
	}
	public Airline getAirlineByCode(String code) {
		for(int i=0; i<airlines.size(); i++) {
			if(airlines.get(i).getCode().equals(code)) {
				return airlines.get(i);
			}
		}
		return null;
	}
	public ArrayList<Airline> getAllAirline() {
		return airlines;
	}
	//Flight
	public void addFlight(String flightCode, Flight flight) {
		this.flightMap.put(flightCode, flight);
	}
	public void updateFlightStatus(Flight flight, char status) {
		/*
		for(Flight f : flightMap.values()) {
			if(f.getFlightNumber() == flight.getFlightNumber()) {
				f.setStatus(status);					
			}
		}	
		*/		
		for(HashMap.Entry<String, Flight> entry:flightMap.entrySet()){    
	        String key=entry.getKey();  
	        Flight b=entry.getValue();  
	        if(b.getFlightNumber() == flight.getFlightNumber()) {
	        	flightMap.get(key).setStatus(status);
	        }  
	    }    
	}
	public Flight getFlight(String flightCode) {		
		return (Flight)flightMap.get(flightCode);
		/*
		for(HashMap.Entry<String, Flight> entry:flightMap.entrySet()){    
	        String key=entry.getKey();  
	        Flight b=entry.getValue();  
	        if(key.equals(flightCode)) {
	        	return b;
	        }/*
	        if(b.getFlightNumber() == flight.getFlightNumber()) {
	        	flightMap.get(key).setStatus(status);
	        }  
	    }
		return null;
		*/
	}
	public ArrayList<Flight> getAllFlight(){
		ArrayList<Flight> flight = new ArrayList<Flight>(flightMap.values());
		return flight;
	}
	
	//Sort
	public ArrayList<Flight> getSortedDepartures(){
		
		ArrayList<Flight> sortFlight = new ArrayList<Flight>(flightMap.values());	
		Collections.sort(sortFlight, new Comparator<Flight>() {
			public int compare(Flight f1, Flight f2) {
				return Integer.valueOf(f1.getDepartureInfo().getTime()).compareTo(f2.getDepartureInfo().getTime());
			}
		});
		return sortFlight;
		
		
		/*
		List<String> mapKeys = new ArrayList<String>(flightMap.keySet());
	    List<Flight> mapValues = new ArrayList<Flight>(flightMap.values());

	    HashMap<String, Flight> sortedMap = new HashMap<String,Flight>();

	    Iterator<Flight> valueIt = mapValues.iterator();
	    while (valueIt.hasNext()) {
	        Flight val = valueIt.next();
	        Iterator<String> keyIt = mapKeys.iterator();

	        while (keyIt.hasNext()) {
	            String key = keyIt.next();
	            String comp1 = passedMap.get(key);
	            String comp2 = val;

	            if (comp1.equals(comp2)) {
	                keyIt.remove();
	                sortedMap.put(key, val);
	                break;
	            }
	        }
	    }*/
		//return this.flightMap.
	}
	public ArrayList<Flight> getSortedArrivals(){
		ArrayList<Flight> sortFlight = new ArrayList<Flight>(flightMap.values());	
		Collections.sort(sortFlight, new Comparator<Flight>() {
			public int compare(Flight f1, Flight f2) {
				return Integer.valueOf(f1.getArrivalInfo().getTime()).compareTo(f2.getArrivalInfo().getTime());
			}
		});
		return sortFlight;
	}
}
