package airlineproject;

import java.util.ArrayList;
import java.util.Scanner;

public class MainMenu {
	public MainMenu() {
		Scanner cin = new Scanner(System.in);
		FlightSchedule flightSchedule = new FlightSchedule();
		String yesno = "";
		while(true) {
			System.out.println(" _________________________________________________________________");
			System.out.println("| Program Menu                                                    |");
			System.out.println("| Welcome Screen                                                  |");
			System.out.println("| Welcome to the Flight Scheduler!                                |");
			System.out.println("| Please remember to always use U, M, T, W, R, F, S, for entering |");
			System.out.println("| the day of the week, and to always use military time for        |");
			System.out.println("| entering the time.                                              |");
			System.out.println("| By entering the corresponding menu number:                      |");
			System.out.println("|                                                                 |");
			System.out.println("| 1. Add Airline                                                  |");
			System.out.println("| 2. Add Flight                                                   |");
			System.out.println("| 3. Update Flight Status                                         |");
			System.out.println("| 4. Show Flight Info                                             |");
			System.out.println("| 5. Show Departures                                              |");
			System.out.println("| 6. Show Arrivals                                                |");
			System.out.println("| 7. Clear Schedule                                               |");
			System.out.println("|_________________________________________________________________|");
			String ch = "";
			ch = cin.nextLine();
			switch (ch) {
			case "1":
				while(true) {
					String name = "";
					String code = "";
					String model = "";
					int fc = 0;
					int bc = 0;
					int ec = 0;	
					Boolean check = true;
					
					System.out.println("============= Add Airline =============");
					System.out.println("Airline Code: "); code = cin.nextLine();
					System.out.println("Airline Name: "); name = cin.nextLine();
					System.out.println("Aircraft Model: "); model = cin.nextLine();
					System.out.println("First Class Capacity: "); fc = cin.nextInt();
					System.out.println("Business Class Capacity: "); bc = cin.nextInt();
					System.out.println("Economy Class Capacity: "); ec = cin.nextInt();					
					System.out.println("----------------------------------------");		
					
					if(name.equals("") || code.equals("") || model.equals("")) {
						System.out.println("Some infomation is missing!");
						cin.nextLine();
						check = false;
					}
					/*
					if(fc == 0 || bc == 0 || ec == 0 ) {
						System.out.println("Some infomation is missing!");
						cin.nextLine();
						check = false;
					}
					*/
					if(flightSchedule.getAirlineByCode(code) != null) {
						System.out.println("Some infomation is missing!");
						cin.nextLine();
						check = false;
					}
					if(!check) {
						continue;
					}
					
					Airline line = new Airline(name, code);
					Aircraft craft = new Aircraft(model, fc, bc, ec);					
					line.add(craft);
					flightSchedule.addAirline(line);
					
					System.out.println(name + " was successfully added.");
					System.out.println("----------------------------------------");
					System.out.println("Do you want to add more airline? (Y/N)");				
					yesno = "";
					cin.nextLine();
					yesno = cin.nextLine();
					if(yesno.toUpperCase().equals("N")) {
						break;
					}
				}
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}
				break;
			case "2":
				while(true) {
					String airlinecode = "";
					String departureAirportCode = "";
					String departureAirportGate = "";
					String arrivalAirportCode = "";
					String arrivalAirportGate = "";
					
					int flightnumber = 0;
					int departureTime = 0;
					int arrivalTime = 0;
					
					char status = 'S';
					char type = ' ';		
					char departureDayofweek = ' ';
					char arrivalDayofweek = ' ';
					
					Boolean check = true;
					int i = 0;
					
					System.out.println("============= Add Flight =============");
					if(flightSchedule.getAllAirline().size() == 0) {
						System.out.println("Add Airline first");
						break;
					}
					System.out.println("Airline code: "); airlinecode = cin.nextLine();					
					for(i=0; i<flightSchedule.getAllAirline().size(); i++) {
						if(flightSchedule.getAllAirline().get(i).getCode().equals(airlinecode)) {
							check = false;
							break;
						}
					}
					if(check) {
						continue;
					}
					System.out.println("Flight number: "); flightnumber = cin.nextInt();
					check = true;
					for(int j=0; j<flightSchedule.getAllFlight().size(); j++) {
						if(flightSchedule.getAllFlight().get(j).getFlightNumber() == flightnumber) {
							System.out.println("Some infomation is missing!");
							cin.nextLine();
							check = false;
							
						}
					}
					if(!check) {
						break;
					}
					
					System.out.println("Type (D for domestic or I for international): ");
					type = cin.next(".").charAt(0);
					cin.nextLine();
					System.out.println("Departure airport code: "); departureAirportCode = cin.nextLine();
					System.out.println("Departure gate: "); departureAirportGate = cin.nextLine();
					System.out.println("Departure day: "); departureDayofweek = cin.next(".").charAt(0);
					System.out.println("Departure time: "); departureTime = cin.nextInt();
					cin.nextLine();
					System.out.println("Arrival airport code: "); arrivalAirportCode = cin.nextLine();
					System.out.println("Arrival gate: "); arrivalAirportGate = cin.nextLine();
					System.out.println("Arrival day: "); arrivalDayofweek = cin.next(".").charAt(0);
					System.out.println("Arrival time: "); arrivalTime = cin.nextInt();
					System.out.println("----------------------------------------");	
					
					check = true;
					
					if(flightnumber == 0 || !(type == 'D' || type == 'I')) {
						System.out.println("Some infomation is missing!");
						cin.nextLine();
						check = false;
					}
					
					if(departureAirportCode.equals("") || departureAirportGate.equals("") || departureDayofweek == ' '
						|| departureTime == 0) {
						System.out.println("Some infomation is missing!");
						cin.nextLine();
						check = false;
					}
					
					if(arrivalAirportCode.equals("") || arrivalAirportGate.equals("") || arrivalDayofweek == ' '
						|| arrivalTime == 0) {
						System.out.println("Some infomation is missing!");
						cin.nextLine();
						check = false;
					}
					for(int j=0; j<flightSchedule.getAllFlight().size(); j++) {
						if(flightSchedule.getAllFlight().get(j).getFlightNumber() == flightnumber) {
							System.out.println("Some infomation is missing!");
							cin.nextLine();
							check = false;
							
						}
					}
					if(!check) {
						break;
					}
					
					DepartureArrivalInfo departureInfo = new DepartureArrivalInfo
							(departureDayofweek, departureTime, departureDayofweek, departureAirportCode, departureAirportGate);
					DepartureArrivalInfo arrivalInfo = new DepartureArrivalInfo
							(arrivalDayofweek, arrivalTime, arrivalDayofweek, arrivalAirportCode, arrivalAirportGate);
					Flight flightObj = new Flight
							(flightSchedule.getAllAirline().get(i), flightnumber, status, type, departureInfo, arrivalInfo);
					flightSchedule.addFlight(flightSchedule.getAllFlight().size()+ "", 
										flightObj);
					
					System.out.println(flightnumber + " was successfully added.");
					System.out.println("----------------------------------------");
					System.out.println("Do you want to add more flight? (Y/N)");				
					yesno = "";
					cin.nextLine();
					yesno = cin.nextLine();
					if(yesno.toUpperCase().equals("N")) {
						break;
					}
				}
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}				
				break;	
			case "3":
			{				
				String airlinecode = "";
				char status = ' ';
				Boolean check = false;
				int i = 0, j = 0;
				int flightNumber = 0;
				
				System.out.println("============= Update Flight Status =============");
				//If no Airline
				if(flightSchedule.getAllAirline().size() == 0) {
					System.out.println("Add Airline first");
					break;
				}
				System.out.println("Enter Airline Code: "); airlinecode = cin.nextLine();					
				for(i=0; i<flightSchedule.getAllAirline().size(); i++) {
					if(flightSchedule.getAllAirline().get(i).getCode().equals(airlinecode)) {
						//If no Flight
						if(flightSchedule.getAllFlight().size() == 0) {
							System.out.println("Add Flight First");
							break;
						}					
						System.out.println("Enter Flight Number: "); flightNumber = cin.nextInt();
						for(j=0; j<flightSchedule.getAllFlight().size(); j++) {
							if(flightSchedule.getAllFlight().get(j).getFlightNumber() == flightNumber) {
								check = true;
								break;
							}							
						}
						if(check) {
							System.out.println("Enter Flight Status(S,D,A,C) = ") ; status = cin.next(".").charAt(0);
							if(status == 'S' || status == 'D' || status == 'A' || status == 'C') {
								flightSchedule.updateFlightStatus(flightSchedule.getAllFlight().get(j), status);
								System.out.println("---------------------------------------------------------");
								System.out.println("You have successfully updated status of flight " 
														+ flightSchedule.getAllFlight().get(j).getFlightNumber());
							}
							else {
								System.out.println("---------------------------------------------------------");
								System.out.println("You haven't successfully updated status of flight " 
										+ flightSchedule.getAllFlight().get(j).getFlightNumber());
							}
						}
						else {
							System.out.println("No Flight in this Airline");
						}
						break;
					}
				}
				System.out.println("---------------------------------------------------------");	
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				cin.nextLine();
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}	
			}			
				break;
			case "4":
			{
				String airlinecode = "";				
				Boolean check = false;
				int i = 0, j = 0;
				int flightNumber = 0;
				
				System.out.println("============= Search Flight Info =============");
				//If airline code is null
				if(flightSchedule.getAllAirline().size() == 0) {
					System.out.println("Add Airline first");
					break;
				}
				System.out.println("Enter Airline Code: "); airlinecode = cin.nextLine();					
				for(i=0; i<flightSchedule.getAllAirline().size(); i++) {
					if(flightSchedule.getAllAirline().get(i).getCode().equals(airlinecode)) {
						//If Flight is null
						if(flightSchedule.getAllFlight().size() == 0) {
							System.out.println("Add Flight First");
							break;
						}					
						System.out.println("Enter Flight Code: "); flightNumber = cin.nextInt();
						for(j=0; j<flightSchedule.getAllFlight().size(); j++) {
							if(flightSchedule.getAllFlight().get(j).getFlightNumber() == flightNumber) {
								check = true;
								break;
							}							
						}
						if(check) {
							System.out.println("-------------------------------------------");	
							System.out.println(flightSchedule.getFlight(j+"").toString());
							//System.out.println(flightSchedule.getAllFlight().get(j).toString());
						}
						else {
							System.out.println("No Flight in this Airline");
						}
						break;
					}
				}
				System.out.println("-------------------------------------------");	
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				cin.nextLine();
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}		
			}
				break;
			case "5": 
			{
				String airportCode = "";
				char day = ' '; 
				Boolean check = false;
				System.out.println("============= Show all Departures =============");
				//If airport code is null
				if(flightSchedule.getSortedDepartures().size() == 0) {
					System.out.println("Add Flight first");
					break;
				}
				System.out.println("Enter Airport Code: "); airportCode = cin.nextLine();
				for(int i=0; i<flightSchedule.getSortedDepartures().size(); i++) {
					if(flightSchedule.getSortedDepartures().get(i).getDepartureInfo().getAirportCode().equals(airportCode)) {
						check = true;
					}
				}
				if(check) {
					System.out.println("Enter Day: "); day = cin.next(".").charAt(0);
					System.out.println("Flights departure from airport " + airportCode + " :");
					System.out.println("-----------------------------------------------------");
					System.out.println("Flight     Status     Time     Destination     Gate");
					System.out.println("-----------------------------------------------------");
					for(int i=0; i<flightSchedule.getSortedDepartures().size(); i++) {
						if(flightSchedule.getSortedDepartures().get(i).getDepartureInfo().getAirportCode().equals(airportCode)) {
							if(flightSchedule.getSortedDepartures().get(i).getDepartureInfo().getDayOfWeek() == day) {
								System.out.println(flightSchedule.getSortedDepartures().get(i).getFlightNumber() + "     "
										+ flightSchedule.getSortedDepartures().get(i).getStatus() + "     "
										+ flightSchedule.getSortedDepartures().get(i).getDepartureInfo().getTime() + "     "
										+ flightSchedule.getSortedDepartures().get(i).getDepartureInfo().getAirportCode() + "     "
										+ flightSchedule.getSortedDepartures().get(i).getDepartureInfo().getAirportGate());
							}						
						}
					}
					System.out.println("-----------------------------------------------------");					
				}
				else {
					System.out.println("No Airport Code");
				}
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				cin.nextLine();
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}		
			}
			break;
			case "6":
			{
				String airportCode = "";
				char day = ' '; 
				Boolean check = false;
				System.out.println("============= Show all Arrivals =============");
				//If airport code is null
				if(flightSchedule.getSortedArrivals().size() == 0) {
					System.out.println("Add Flight first");
					break;
				}
				System.out.println("Enter Airport Code: "); airportCode = cin.nextLine();
				for(int i=0; i<flightSchedule.getSortedArrivals().size(); i++) {
					if(flightSchedule.getSortedArrivals().get(i).getArrivalInfo().getAirportCode().equals(airportCode)) {
						check = true;
					}
				}
				if(check) {
					System.out.println("Enter Day: "); day = cin.next(".").charAt(0);
					System.out.println("Flights arrival in airport " + airportCode + " :");
					System.out.println("-----------------------------------------------------");
					System.out.println("Flight     Status     Time     Destination     Gate");
					System.out.println("-----------------------------------------------------");
					for(int i=0; i<flightSchedule.getSortedArrivals().size(); i++) {
						if(flightSchedule.getSortedArrivals().get(i).getArrivalInfo().getAirportCode().equals(airportCode)) {
							if(flightSchedule.getSortedArrivals().get(i).getArrivalInfo().getDayOfWeek() == day) {
								System.out.println(flightSchedule.getSortedArrivals().get(i).getFlightNumber() + "     "
										+ flightSchedule.getSortedArrivals().get(i).getStatus() + "     "
										+ flightSchedule.getSortedArrivals().get(i).getArrivalInfo().getTime() + "     "
										+ flightSchedule.getSortedArrivals().get(i).getArrivalInfo().getAirportCode() + "     "
										+ flightSchedule.getSortedArrivals().get(i).getArrivalInfo().getAirportGate());
							}						
						}
					}
					System.out.println("-----------------------------------------------------");					
				}
				else {
					System.out.println("No Airport Code");
				}
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				cin.nextLine();
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}						
			}
			break;
			case "7":
			{
				System.out.println("-----------------------------------------------------");
				System.out.println("Are you sure you want to clear the schedule and start over? (Y/N)");
				yesno = "";
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("Y")) {
					flightSchedule.deleteAllRecords();
					System.out.println("The flight schedule is cleared");
				}	
				else {
					System.out.println("The flight schedule is not cleared");
				}
				System.out.println("-----------------------------------------------------");
				System.out.println("Do you want to continue to Main Menu? (Y/N)");
				yesno = "";
				yesno = cin.nextLine();
				if(yesno.toUpperCase().equals("N")) {
					System.exit(0);
				}		
			}
			break;			
			default:
				break;
			}
		}
	}
}
