package airlineproject;

public class Flight {
	private Airline airline;
	private int flightNumber;
	private char status;
	private char type;
	private DepartureArrivalInfo departureInfo;
	private DepartureArrivalInfo arrivalInfo;
	
	public Flight(Airline airline, int flightNumber, char status, char type, 
				DepartureArrivalInfo departureInfo,
				DepartureArrivalInfo arrivalInfo) {
		this.airline = airline;
		this.flightNumber = flightNumber;
		this.status = status;
		this.type = type;
		this.departureInfo = departureInfo;
		this.arrivalInfo = arrivalInfo;
	}
	public DepartureArrivalInfo getDepartureInfo() {
		return departureInfo;
	}
	public DepartureArrivalInfo getArrivalInfo() {
		return arrivalInfo;
	}
	public void setStatus(char status) {
		this.status = status;
	}
	public char getStatus() {
		return status;
	}
	public Airline getAirline() {
		return airline;
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public String toString() {
		return  "Flight = " + flightNumber 
				+ "\nType = " + type
				+ "\nStatus = " + status + "\n" + airline.toString() 
				
				+ "\nDeparture Day = " + departureInfo.getDayOfWeek() 
				+ "\nDeparture Time = " + departureInfo.getTime()
				+ "\nDeparture Airport = " + departureInfo.getAirportCode()
				+ "\nDeparture Gate = " + departureInfo.getAirportGate()
				
				+ "\n\nArrival Day = " + arrivalInfo.getDayOfWeek() 
				+ "\nArrival Time = " + arrivalInfo.getTime()
				+ "\nArrival Airport = " + arrivalInfo.getAirportCode()
				+ "\nArrival Gate = " + arrivalInfo.getAirportGate();				
 	}
	
}
