package airlineproject;

import java.util.ArrayList;

public class Airline {
	//Data Member
	private String name;
	private String code;
	private ArrayList<Aircraft> aircraft = new ArrayList<Aircraft>();
	
	//Method Member
	public Airline(String name, String code) {
		this.name = name;
		this.code = code;
	}
	public void add(Aircraft aircraft) {
		this.aircraft.add(aircraft);
	}
	public String getCode() {
		return code;
	}
	public ArrayList<Aircraft> getAircraft() {
		return this.aircraft;
	}
	public void remove(Aircraft aircraft) {
		this.aircraft.remove(aircraft);
	}
	public String toString() {
		String result = "";
		for(int i=0; i<aircraft.size(); i++) {
			result += aircraft.get(0).toString();
		}
		return result;
		//if we don't put .get(0) it will show [  ] 
	}
}
