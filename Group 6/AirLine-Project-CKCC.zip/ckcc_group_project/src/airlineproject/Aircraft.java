package airlineproject;

public class Aircraft {
	//Data Member
	private String model;
	private int firstClassCapacity;
	private int businessClassCapacity;
	private int economyClassCapacity;
	
	//Method Member
	public Aircraft(String model, int fc, int bc, int ec) {
		this.model = model;
		this.firstClassCapacity = fc;
		this.businessClassCapacity = bc;
		this.economyClassCapacity = ec;
	}
	public String toString() {
		return "Model = " + model + "\nFirst Class Capacity = " + firstClassCapacity
				+ "\nBusiness Class Capacity = " + businessClassCapacity 
				+ "\nEconomy Class Capacity = " + economyClassCapacity + "\n";
	}
}
