package Library;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		Menu menu = new Menu();
		Scanner input = new Scanner(System.in);
		
		boolean check = true;
		while(check) {
			menu.menu();
			System.out.print("Please choose function (1-8):");
			int choice =input.nextInt();
			switch(choice) {
				case 1: 			
					menu.addBook();
					break;
				
				case 2:
					menu.addThesis();
					break;
				
				case 3:
					menu.addMember();
					break;
				case 4:
					menu.library.addTransaction();
					break;
					
				case 5:
					menu.library.removeTransaction();
					break;
				
				case 6:
					menu.library.viewMember();
					break;
				case 7:
					menu.library.view();
					break;
					
				case 8:
					menu.library.listTransaction();
					break;
				
				case 0:
					System.out.println("Bye");
					System.exit(0);
					check = false;
				default:
					System.out.println("Please input again(1-8): ");
			}
		
		}
	}	
}
