package Library;

public class Transaction {
	private int id;
	private Member member;
	private BookModel book;
	private String dateOfIssue;
	private String dueDate;
	public Transaction(Member member, BookModel book, String dateOfIssue, String dueDate) {
		super();
		//this.id = id;
		this.member = member;
		this.book = book;
		this.dateOfIssue = dateOfIssue;
		this.dueDate = dueDate;
	}
	
	public int getID() {
		return id;
	}

	public BookModel getBook() {
		return book;
	}

	@Override
	public String toString() {
		return id+"\t"+member.getName()+"\t"+book.getTitle()+"\t"+dateOfIssue+"\t"+dueDate;
	}

	
	
	
	
	
	
	
	
}
