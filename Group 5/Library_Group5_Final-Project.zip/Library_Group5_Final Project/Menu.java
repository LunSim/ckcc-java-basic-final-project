package Library;

import java.util.Scanner;

public class Menu {
	Scanner input = new Scanner(System.in);
	Library library = new Library();
	void menu() {

		System.out.println("---- Program Menus ----------\r\n" + 
				"| 1. Add new book               |\r\n" + 
				"| 2. Add new thesis             |\r\n" + 
				"| 3. Add new member             |\r\n" + 
				"| 4. Borrow a book              |\r\n" + 
				"| 5. Return a book              |\r\n" + 
				"| 6. List members               |\r\n" + 
				"| 7. List books by category     |\r\n" + 
				"| 8. List of borrowed books     |\r\n" + 
				"-----------------------------");
	}
	
	void addBook() {
		System.out.println("----------------- Add New Book --------------------");
		
		System.out.print("Enter book id:");
		String id =input.next();
		
		System.out.print("Enter title:");
		String title =input.next();

		System.out.print("Enter publisher:");
		String publisher=input.next();
		
		System.out.print("Enter yearPublished:");
		String yearPublished=input.next();
		
		System.out.print("Enter status iSBN:");
		String iSBN=input.next();
		
		System.out.print("Enter price:");
		double price = input.nextDouble();
		
		System.out.print("Enter author:");
		String author = input.next();
		
		System.out.print("Enter edition:");
		int edition = input.nextInt();
		
		Book book =new Book(id, title, publisher, yearPublished, true, iSBN, price, author, edition);
		library.addBook(book);
		
		System.out.println("You added successfully");
		System.out.println("Do you want to Add more(Press Y to continue add, Press any key to Main Menu ):");
		String answer=input.next();
		if(answer.equals("y") || answer.equals("Y")) {
			addBook();
		}

	}
	
	void addThesis() {
		
		
		System.out.print("Enter book id:");
		String id =input.next();
		
		System.out.print("Enter title:");
		String title =input.next();

		System.out.print("Enter publisher:");
		String publisher=input.next();
		
		System.out.print("Enter yearPublished:");
		String yearPublished=input.next();
		
		System.out.print("Enter Writer:");
		String writer=input.next();
		
		System.out.print("Enter Type of Thesis:");
		String type = input.next();
		
		Thesis thesis =new Thesis(id, title, publisher, yearPublished,true, writer, type);
		library.addThesis(thesis);
	}
	
	void addMember() {
		
		System.out.print("Enter ID:");
		String id =input.next();
		
		System.out.print("Enter name:");
		String name = input.next();
		
		System.out.print("Enter address:");
		String address=input.next();
	
		System.out.print("Enter date of Membership:");
		String dateOfMembership=input.next();
		
		System.out.print("Enter Type of membership:");
		String membershipType=input.next();
		
		Member member = new Member(id, name, address, dateOfMembership, membershipType);
		
		library.addMember(member);
		
		System.out.println("You added successfully");
		System.out.println("Do you want to Add more(Press Y to continue add, Press any key to Main Menu ):");
		String answer=input.next();
		if(answer.equals("y") || answer.equals("Y")) {
			addMember();
		}
	
	}
	

	
	

	
	
	
	
}
