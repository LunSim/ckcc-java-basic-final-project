//package Library;
//
//public static class Option {
//
//	
//	
//	void oneOption() {
//		System.out.println("do you want to Main Menu(Press Y to Main Menu, Press any key to exit ):");
//		String answer=input.next();
//		if(answer.equals("y") || answer.equals("Y")) {
//			HunsenLibraryMenu();
//		}
//		else  {
//			System.out.println("bye bye");
//			System.exit(1);
//		}
//	}
//	
//	
//}
