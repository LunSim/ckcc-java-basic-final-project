package Library;

public class BookModel {
	private String id;
	private String title;
	private String publisher;
	private String yearPublished;
	private boolean status;
	
	public static int count;

	public BookModel(String id, String title, String publisher, String yearPublished, boolean status) {
		//super();
		this.id = id;
		this.title = title;
		this.publisher = publisher;
		this.yearPublished = yearPublished;
		this.status = status;
	}
	

	public String getID() {
		return id;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}
	public boolean getStatus() {
		return status;
	}
	
	public String getTitle() {
		return title;
	}
	public String getPublisher() {
		return publisher;
	}
	
	public String getYearPublished() {
		return yearPublished;
	}


	@Override
	public String toString() {
		return "BookModel [id=" + id + ", title=" + title + ", publisher=" + publisher + ", yearPublished="
				+ yearPublished + ", status=" + status + "]";
	}
	
	
	
	
	
}
