package Library;

public class Book extends BookModel {
	private String ISBN;
	private double price;
	private String author;
	private int edition;
	
	
	public Book(String id, String title, String publisher, String yearPublished, boolean status, String iSBN,
			double price, String author, int edition) {
		super(id, title, publisher, yearPublished, status);
		ISBN = iSBN;
		this.price = price;
		this.author = author;
		this.edition = edition;
	}


	@Override
	public String toString() {
		return getID()+"\t "+getTitle()+"\t \t "+getPublisher()+"\t \t "+getYearPublished()+"\t \t "+getStatus()+"\t "+
				ISBN+"\t  "+price+"\t "+author+"\t "+edition;
	}



	
	
	
}
