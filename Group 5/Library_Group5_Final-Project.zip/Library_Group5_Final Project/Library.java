package Library;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Library {
	
	private HashMap<String, Book> books = new HashMap<>();
	private HashMap<String, Member> members = new HashMap<>();
	private ArrayList<Transaction> transactions = new ArrayList<>();
	private HashMap<String,Thesis> thesis = new HashMap<>();

	Scanner input = new Scanner(System.in);
	Library(){
		
	}
	
	public void addBook(Book b) {
		books.put(b.getID()+"", b);
	}
	
	public Book getBook(String bookID) {
		Book bookModel = books.get(bookID);
		return bookModel; 
	}
	
	public ArrayList<Book> getAllBooks(){
		ArrayList<Book> getAllBook = new ArrayList<>();
		Set set =books.entrySet();
		Iterator it =set.iterator();
		while (it.hasNext()) {
			Map.Entry mentry = (Map.Entry)it.next();
			getAllBook.add((Book) mentry.getValue());
		}
		return getAllBook;
	}
	
	
	
	
	public void addThesis(Thesis t) {
		thesis.put(t.getID()+"", t);
	}
	
	public ArrayList<Thesis> getAllThesis(){
		ArrayList<Thesis> getAllthesis = new ArrayList<>();
		Set set =thesis.entrySet();
		Iterator it =set.iterator();
		while (it.hasNext()) {
			Map.Entry mentry = (Map.Entry)it.next();
			getAllthesis.add((Thesis) mentry.getValue());
		}
		return getAllthesis;
	}
	
	
	public void view() {
		
		
		System.out.println("----------------- Book List -------------------------------------------------------------------------");
		System.out.println("Book Total:"+books.size());
		System.out.println("-------------------------------------------------------------------------------------------------------");
		System.out.println("ID \t Tiltle \t Publisher \t PublisherYear \t Status\t ISBN\t Price "
				+ "\t "+"Author\t Edition");
		System.out.println("");
		
		Iterator itThesis = books.entrySet().iterator();
	    while (itThesis.hasNext()) {
	        Map.Entry pair = (Map.Entry)itThesis.next();
	        System.out.println(pair.getValue());
	        //itbook.remove(); // avoids a ConcurrentModificationException
	    }
	    System.out.println("-------------------------------------------------------------------------------------------------------");
	    
//	    Iterator itthesis = thesis.entrySet().iterator();
//	    while (itthesis.hasNext()) {
//	        Map.Entry pair = (Map.Entry)itthesis.next();
//	        System.out.println(pair.getKey() + " = " + pair.getValue());
//	        itthesis.remove(); // avoids a ConcurrentModificationException
//	    }
	    
		
	}
	
	
	public void addMember(Member m) {
		members.put(m.getID()+"", m);
		
	}
	
	
	public ArrayList<Member> getAllMember(){
		ArrayList<Member> getAllMember = new ArrayList<>();
		Set set =members.entrySet();
		Iterator it =set.iterator();
		while (it.hasNext()) {
			Map.Entry mentry = (Map.Entry)it.next();
			getAllMember.add((Member) mentry.getValue());
		}
		return getAllMember;
	}
	
	
	public void viewMember() {
		
		System.out.println("-----------------Member List -------------------------------------------------------------------------");
	
		System.out.println("ID\tName\tAddress\t Date\t MemberShip");
		
		Iterator it = members.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        System.out.println(pair.getValue());
	       
	    }
	    System.out.println("-------------------------------------------------------------------------------------------------------");
	   
	    
		
	}
	
	

	public void addTransaction(Transaction t) {
		transactions.add(t);
	}
	void addTransaction() {
		
		System.out.println("Enter member id:");
		String idMember = input.next();
		Member member = members.get(idMember);
		boolean find=false;
		
		for(Member m:members.values())
		{ 
		  if (m.getID().equals(idMember)) {
			  System.out.println("Enter book id:");
			  String idBook=input.next();
			  for(Book b:books.values())
				{ 
				  if (b.getID().equals(idBook)) {
					  books.get(idBook).setStatus(false);
						
						Book book = books.get(idBook);
						System.out.println("Enter date of Issue:");
						String dateOfIssue=input.next();
						
						System.out.println("Enter Due Date:");
						String dueDate=input.next();
						
						
						Transaction transaction =new Transaction(member, book, dateOfIssue, dueDate);
						
						addTransaction(transaction);
						System.out.println("You've borrowed book successfully");
						break;
				  }
				  else {
					  System.out.println("Book with ID"+ idBook +"is not found!");
					  
				  }
				  
				}
			  
			  find=true;
			  
		  }
		  
		 
		}
		
		if(find==false) {
			System.out.println("Member with ID"+ idMember +"is not found!");
		}
		
		
		System.out.println("Do you want to Main Menu(Y/N ):");
		String answer=input.next();
			
		if(answer.equals("n") || answer.equals("n")) {
				
			addTransaction();
		}	
		
		
	}
	
	public void listTransaction() {
		System.out.println("ID \tMember\t Book\t Issue\t Due");
		for(Transaction t : transactions) {
			System.out.println(t);
		}
		System.out.println("Do you want to Main Menu(Y/N ):");
		String answer=input.next();
			
		if(answer.equals("n") || answer.equals("n")) {
				
			removeTransaction();
		}	
	}
	
	public void removeTransaction () {
		
		System.out.println("ID:");
		int id =input.nextInt();
		
		if(id>0&&id<=transactions.size()) {
			System.out.println("Book " +transactions.get(id-1).getBook().getTitle() +"is returned successfully");
			books.get(transactions.get(id-1).getBook().getID()).setStatus(true);
			transactions.remove(id-1);
			
			System.out.println("Do you want to return more(Press Y to continue return, Press any key to Main Menu ):");
			String answer=input.next();
			if(answer.equals("y") || answer.equals("Y")) {
				removeTransaction();
			}
			
		}
			
		
		else {
			
			System.out.println("Transaction with ID"+ id +"is not found!");
			System.out.println("Do you want to Main Menu(Y/N ):");
			String answer=input.next();
				
			if(answer.equals("n") || answer.equals("n")) {
					
				removeTransaction();
			}	
			
		}
		
		
	
	}

	
	
	
}
