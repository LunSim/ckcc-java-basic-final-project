package Library;

public class Member {
	private String id;
	private String name;
	private String address;
	private String dateOfMembership;
	private String membershipType;
	public Member(String id, String name, String address, String dateOfMembership, String membershipType) {
		
		this.id = id;
		this.name = name;
		this.address = address;
		this.dateOfMembership = dateOfMembership;
		this.membershipType = membershipType;
	}
	
	public String getID() {
		return id;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return id+" \t"+name+" \t"+address+" \t"+ dateOfMembership+"\t"+ membershipType;
	}
	
	
	
}
